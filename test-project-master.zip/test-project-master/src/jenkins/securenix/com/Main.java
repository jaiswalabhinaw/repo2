package jenkins.securenix.com;

public class Main {

	public static void main(String[] args) {
		System.out.println("This is a test project");

	}

}
